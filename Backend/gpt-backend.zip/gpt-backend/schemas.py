from pydantic import BaseModel, EmailStr
from typing import List, Optional

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: int
    username: str
    email: EmailStr

    class Config:
        orm_mode = True

class ScheduleBase(BaseModel):
    startCity: str
    endCity: str
    startDate: str
    endDate: str
    userEmotion: List[str]
    with_: List[str]

class ScheduleCreate(ScheduleBase):
    schedule_json: Optional[dict]

class ScheduleResponse(BaseModel):
    id: int
    user_id: int
    start_city: str
    end_city: str
    start_date: str
    end_date: str
    emotions: str
    companions: str
    schedule_json: str

    class Config:
        orm_mode = True
